const pizzas = [
  {
    id: 1,
    name: "Napolitana",
    price: 5950,
    ingredientes: "Pizza con tomate, mozzarella y un poco de jamón y olives.",
    img: "https://images.pexels.com/photos/2147491/pexels-photo-2147491.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
  },
  {
    id: 2,
    name: "Española",
    price: 7500,
    ingredientes: "Pizza con tomate, mozzarella, jamón y provolone.",
    img: "https://images.pexels.com/photos/365459/pexels-photo-365459.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
  },
  {
    id: 3,
    name: "Vegetariana",
    price: 6500,
    ingredientes: "Pizza con tomate, mozzarella, olives y un poco de cebolla.",
    img: "https://images.pexels.com/photos/19239118/pexels-photo-19239118/free-photo-of-comida-italiano-pizza-restaurante.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
  },
  {
    id: 4,
    name: "Napolitana 2",
    price: 5950,
    ingredientes: "Pizza con tomate, mozzarella y un poco de jamón y olives.",
    img: "https://images.pexels.com/photos/2147491/pexels-photo-2147491.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
  },
  {
    id: 5,
    name: "Española 2",
    price: 7500,
    ingredientes: "Pizza con tomate, mozzarella, jamón y provolone.",
    img: "https://images.pexels.com/photos/365459/pexels-photo-365459.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
  },
  {
    id: 6,
    name: "Vegetariana 2",
    price: 6500,
    ingredientes: "Pizza con tomate, mozzarella, olives y un poco de cebolla.",
    img: "https://images.pexels.com/photos/19239118/pexels-photo-19239118/free-photo-of-comida-italiano-pizza-restaurante.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
  },
];

export default pizzas;
