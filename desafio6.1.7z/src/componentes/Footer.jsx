const Footer = () => {
  return (
    <>
      <div className="text-center text-white mt-4 bg-dark p-3">
        <p>© 2021 - Pizzería Mamma Mia! - Todos los derechos reservados</p>
      </div>
    </>
  );
};
export default Footer;
