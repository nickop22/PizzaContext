// CarritoCompras.jsx
import React, { useContext, useState } from "react";
import CartContext from "../context/CartContext";

const Cart = () => {
  const Context = useContext(CartContext);
  const { cart, setCart, addToCart, getTotal, getQuantity, removeFromCart } =
    context || {};
  console.log(cart);

  return (
    <div className="container">
      <h2 className="my-4">Carrito de Compras</h2>
      <div className="list-group">
        {cart.map((producto) => (
          <div
            key={producto.id}
            className="list-group-item d-flex justify-content-between align-items-center"
          >
            <div className="d-flex align-items-center">
              <img
                src={producto.img}
                alt={producto.name}
                className="img-fluid mr-3"
                style={{ maxHeight: "100px", objectFit: "contain" }}
              />
              <div>
                <h5>{producto.name}</h5>
                <p>Precio: ${producto.price}</p>
              </div>
            </div>
            <div className="d-flex align-items-center">
              <button
                className="btn btn-danger mr-2"
                onClick={() => removeFromCart(producto.id)}
              >
                -
              </button>
              <span>{cantidades[producto.id]}</span>
              <button
                className="btn btn-success ml-2"
                onClick={() => addToCart(producto.id)}
              >
                +
              </button>
            </div>
          </div>
        ))}
        <div className="list-group-item">
          <h3>Total: ${getTotal()}</h3>
        </div>
      </div>
    </div>
  );
};

export default Cart;
